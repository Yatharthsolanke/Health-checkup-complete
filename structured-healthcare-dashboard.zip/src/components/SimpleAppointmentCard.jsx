import React from 'react';
import '../styles/SimpleAppointmentCard.css';

function SimpleAppointmentCard({ title, time }) {
  return (
    <div className="appointment-card">
      <span>🩺</span>
      <div>
        <div>{title}</div>
        <div className="time">{time}</div>
      </div>
    </div>
  );
}

export default SimpleAppointmentCard;
