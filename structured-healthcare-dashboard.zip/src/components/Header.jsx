import React from 'react';
import '../styles/Header.css';

function Header() {
  return (
    <div className="header">
      <div className="logo">Healthcare.</div>
      <input className="search-bar" placeholder="Search..." />
      <div className="header-right">
        <span className="notification">🔔</span>
        <span className="profile">👤 Dr. Smith</span>
        <button className="add-button">＋</button>
      </div>
    </div>
  );
}

export default Header;
