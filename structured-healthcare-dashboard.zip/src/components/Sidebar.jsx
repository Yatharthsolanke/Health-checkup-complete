import React from 'react';
import '../styles/Sidebar.css';

const navLinks = [
  'Dashboard', 'History', 'Calendar', 'Appointments',
  'Statistics', 'Tests', 'Chat', 'Support', 'Setting'
];

function Sidebar() {
  return (
    <div className="sidebar">
      <h3>General</h3>
      <ul>
        {navLinks.map(link => <li key={link}>{link}</li>)}
      </ul>
    </div>
  );
}

export default Sidebar;
