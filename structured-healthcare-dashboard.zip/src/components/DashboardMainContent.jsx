import React from 'react';
import '../styles/DashboardMainContent.css';
import SimpleAppointmentCard from './SimpleAppointmentCard';

function DashboardMainContent() {
  return (
    <div className="dashboard">
      <div className="overview">Dashboard Overview</div>

      <div className="anatomy-section">
        <h4>Anatomy</h4>
        <ul>
          <li style={{ color: 'green' }}>Healthy Heart</li>
          <li style={{ color: 'green' }}>Lungs</li>
          <li style={{ color: 'red' }}>Teeth</li>
          <li style={{ color: 'green' }}>Bone</li>
        </ul>
      </div>

      <div className="health-cards">
        <div>Lungs: OK - 02/05/2025</div>
        <div>Teeth: Issue - 01/05/2025</div>
        <div>Bone: OK - 30/04/2025</div>
      </div>

      <div className="calendar-view">
        <h4>October 2021</h4>
        <p>Appointments: 09:00, 11:00, 13:00, 15:00</p>
        <div className="appointment-details">
          <div>Dentist - 09:00</div>
          <div>Physiotherapy - 11:00</div>
        </div>
      </div>

      <div className="upcoming-schedule">
        <h4>On Thursday</h4>
        <SimpleAppointmentCard title="Health checkup complete" time="10:00 AM" />
        <SimpleAppointmentCard title="Ophthalmologist" time="11:30 AM" />
        <h4>On Saturday</h4>
        <SimpleAppointmentCard title="Cardiologist" time="09:00 AM" />
        <SimpleAppointmentCard title="Neurologist" time="01:00 PM" />
      </div>

      <div className="activity-feed">
        <h4>Activity</h4>
        <p>3 appointments this week</p>
        <div className="bar-chart">
          <div className="bar bar1"></div>
          <div className="bar bar2"></div>
          <div className="bar bar3"></div>
        </div>
      </div>
    </div>
  );
}

export default DashboardMainContent;
